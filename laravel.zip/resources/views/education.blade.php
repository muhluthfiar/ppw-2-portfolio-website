@extends('navbar')

@section('content')
<div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>My Education</h1>
                    <h3 >
                        <ul>
                            <li>
                                (2018 - 2019) - Syafana Islamic Schoool
                            </li>
                            <li>
                                (2019 - 2021) - Budi Mulia Dua Highschool
                            </li>
                            <li>
                                (2021 - Present) - University of Gadjah Mada
                            </li>
                        </ul>
                    </h3>
                </div>
            </div>
        </div>
    </div>
@endsection