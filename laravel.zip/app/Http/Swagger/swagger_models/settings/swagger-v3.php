<?php

/**
* @OA\Info(
* description="Contoh API doc menggunakan
OpenAPI/Swagger",
* version="1.0.0",
* title="Contoh API documentation",
* termsOfService="http://swagger.io/terms/",
* @OA\Contact(
* email="djiwandou@gmail.com"
* ),
* @OA\License(
* name="Apache 2.0",
*
url="http://www.apache.org/licenses/LICENSE-2.0.html"
* )
* )
*/

 ?>