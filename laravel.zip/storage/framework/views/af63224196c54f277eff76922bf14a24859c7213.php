

<?php $__env->startSection('content'); ?>
    <div class='main'>
        <div class='container'>
            <?php if(Session::has('successUpdate')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('successUpdate')); ?>

                </div>
            <?php elseif(Session::has('successDelete')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('successDelete')); ?>

                </div>
            <?php elseif(Session::has('successCreate')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('successCreate')); ?>

                </div>

            <?php endif; ?>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>My Projects</h1>
                    <h3>
                        <?php if(count($projects)>0): ?>
                            <ul>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <img src="<?php echo e(asset('storage/ProjectImages/'.$project->picture)); ?>" height='50px'>
                                        <a href="/projects/<?php echo e($project->id); ?>"><?php echo e($project->ProjectTitle); ?></a>
                                        <h6>Created At <?php echo e($project -> created_at); ?></h6>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <h2>No projects found</h2>
                        <?php endif; ?>
                    </h3>
                </div>
            </div>
        </div>
    </div>

<div>
    Halaman : <?php echo e($projects->currentPage()); ?> <br />
    Jumlah Data : <?php echo e($projects->total()); ?> <br />
    Data Per Halaman : <?php echo e($projects->perPage()); ?> <br />
    <div class="d-flex">
        <?php echo e($projects->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('projects.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/projects/index.blade.php ENDPATH**/ ?>