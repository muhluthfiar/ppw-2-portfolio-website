

<?php $__env->startSection('content'); ?>
    <div>
        <h3><?php echo e($data['name']); ?></h3>
        <h4><?php echo e($data['body']); ?></h4>
        <p>Terima kasih</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/emails/sendemail.blade.php ENDPATH**/ ?>