

<?php $__env->startSection('content'); ?>
    <div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'><?php echo e($post->title); ?></h1>
                    <h3 >
                        <p>
                            <?php echo e($post->description); ?>

                        </p>
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('posts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/posts/show.blade.php ENDPATH**/ ?>