

<?php $__env->startSection('content'); ?>
<div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>Contact</h1>
                    <h3 >
                        <ul>
                            <li>
                                <a href='http://github.com/MuhammadLuthfi2003'>My Github</a>
                            </li>
                            <li>
                                <a href='http://twitter.com/muhluthfiar'>My Twitter</a>
                            </li>
                            <li>
                                <a href='http://instagram.com/muhluthfiar_'>My Instagram</a>
                            </li>
                        </ul>
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/contact.blade.php ENDPATH**/ ?>