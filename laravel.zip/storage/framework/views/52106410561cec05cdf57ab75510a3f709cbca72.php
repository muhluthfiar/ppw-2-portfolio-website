

<?php $__env->startSection('content'); ?>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h1 class="text-center">Kirim Email</h1>
                </div>
            </div>
            
            <?php if(session('status')): ?>
            <div class="alert alert-primary" role="alert">
                <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
        </div>

        <div class="container">
            <form action="<?php echo e(route('post-email')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email-destination">Email Tujuan</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email Tujuan">
                </div>
                <div class="form-group">
                    <label for="email-title">Judul Email</label>
                    <input type="text" class="form-control" id="email-title" name="name" placeholder="Masukkan Judul Email">
                </div>
                <div class="form-group">
                    <label for="email-body">Isi Email</label>
                    <textarea class="form-control" id="email-body" name="body" cols="30" rows="10"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Kirim Email</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/kirim-email.blade.php ENDPATH**/ ?>