

<?php $__env->startSection('content'); ?>
<div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>My Education</h1>
                    <h3 >
                        <ul>
                            <li>
                                (2018 - 2019) - Syafana Islamic Schoool
                            </li>
                            <li>
                                (2019 - 2021) - Budi Mulia Dua Highschool
                            </li>
                            <li>
                                (2021 - Present) - University of Gadjah Mada
                            </li>
                        </ul>
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/education.blade.php ENDPATH**/ ?>