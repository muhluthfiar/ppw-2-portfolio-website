

<?php $__env->startSection('content'); ?>
    <div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'><?php echo e($project->ProjectTitle); ?></h1>
                    <h2 class='text-center'>Created At :<?php echo e($project->created_at); ?></h2>
                    <img src="<?php echo e(asset('storage/ProjectImages/'.$project->picture)); ?>">
                    <h3 >
                        <p>
                            <?php echo e($project->ProjectDescription); ?>

                        </p>
                    </h3>
                    
                    <a href="/projects/<?php echo e($project->id); ?>/edit" class="btn btn-primary">Edit</a>
                </div>
                <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" value="<?php echo e($project->id); ?>">
                    <button type="submit" onClick="return confirm('Hapus portfolio?')" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('projects.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/projects/show.blade.php ENDPATH**/ ?>