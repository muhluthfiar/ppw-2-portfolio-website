<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(auth()->guard()->check()): ?>
                        <p>Welcome <b><?php echo e(Auth::user()->name); ?></b></p>
                        <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>">Logout</a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                        <a class="btn btn-info" href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/home.blade.php ENDPATH**/ ?>