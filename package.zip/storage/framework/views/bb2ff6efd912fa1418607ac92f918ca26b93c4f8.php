

<?php $__env->startSection('content'); ?>
    <div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>About Me!</h1>
                    <h3 class='text-center'>
                        I am Muhammad Luthfi Azzahra Rammadhani, I am currently pursuing
                        My Degree on Software Engineering in the University Of Gadjah
                        Mada
                    </h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROGRAMMING\PHP\tugas-portfolio\resources\views/about.blade.php ENDPATH**/ ?>