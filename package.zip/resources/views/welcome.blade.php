@extends('navbar')

@section('content')
    <div class='main'>
        <div class='container'>
            <div class='row'>
                <div class='col-12'>
                    <h1 class='text-center'>Welcome to my website</h1>
                    <h3 class='text-center'>Muhammad Luthfi Azzahra Rammadhani</h3>
                </div>
            </div>
        </div>
    </div>
@endsection
