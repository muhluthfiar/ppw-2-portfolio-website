<html>
    <body>
        <div>
            <h1>{{ $data['name'] }}</h1>
            <h4>{{ $data['body'] }}</h4>
            <p>Terima kasih</p>
        </div>
    </body>
</html>